document.getElementById('createAccountLink').addEventListener('click', function() {
    document.getElementById('sing').style.display = 'none';
    document.getElementById('signinSection').style.display = 'block';
});